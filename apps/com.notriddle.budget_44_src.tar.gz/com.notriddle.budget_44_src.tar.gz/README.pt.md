Orçamento com envelopes
===========================================
Assuma o controle de seu dinheiro. É fácil.
-------------------------------------------

Evite as taxas do saldo negativo, escassez inesperados, a tarefa monótona assim como árdua do pagamento mínimo e o medo quando se da conta que não poderia ir para comer. 

Eso é o propósito de Orçamento; é fácil também. Coloque dineiro nos envelopes no dia de pagamento e retire o que gasta. Um envelope pode representar qualquer coisa—uma conta, dineiro reservado para os comestíveis ou dinheiro que economizou para comprar o novo celular fora de contrato. Pense de um talão de cheques, só mais flexível.

Ao gerir o dinheiro é uma chatice, mas não tem que ser árduo ou difícil.


