package jackpal.androidterm.emulatorview;

import android.test.AndroidTestCase;
// import android.view.KeyEvent;

public class ModifierKeyTest extends AndroidTestCase {

    public void testCtrlKey() {
//		ModifierKey mk = new ModifierKey(KeyEvent.KEYCODE_CTRL_LEFT);
//		assertFalse(mk.isActive());
//		mk.handleModifierKey(KeyEvent.KEYCODE_CTRL_LEFT, true);
//		assertTrue(mk.isActive());
    }
}
