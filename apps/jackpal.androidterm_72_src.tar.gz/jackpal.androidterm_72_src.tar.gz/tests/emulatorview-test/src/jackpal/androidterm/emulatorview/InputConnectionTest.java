package jackpal.androidterm.emulatorview;

import android.test.AndroidTestCase;
// import android.test.mock.MockApplication;
// import android.test.mock.MockContext;
// import android.util.DisplayMetrics;
// import android.view.inputmethod.InputConnection;

public class InputConnectionTest extends AndroidTestCase {

    public InputConnectionTest() {
        super();
    }

    public void testBackSpace() {
//		MockContext cn = new MockContext();
//		MockApplication a = new MockApplication();
//		TermSession ts = new TermSession();
//		DisplayMetrics m = new DisplayMetrics();
//		EmulatorView e = new EmulatorView(cn, ts, m);
//		InputConnection c = e.onCreateInputConnection(null);
    }
}
