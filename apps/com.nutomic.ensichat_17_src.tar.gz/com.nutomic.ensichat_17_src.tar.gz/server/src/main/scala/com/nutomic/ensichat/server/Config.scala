package com.nutomic.ensichat.server

case class Config(name: Option[String] = None, status: Option[String] = None)
