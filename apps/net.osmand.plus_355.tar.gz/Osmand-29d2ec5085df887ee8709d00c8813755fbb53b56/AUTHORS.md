### Credits to all major contributors/developers:
Major contributors /developers listed here https://github.com/osmandapp/osmandapp.github.io/blob/master/website/help/about.html#L8

### Other Pull requests
Copyright © All authors of translations and pull requests could be found in commits history:
 - Translations are under special “contributor” name ‘weblate’
 - Pull requests have two committers, first is original contributor and second is project maintainer
