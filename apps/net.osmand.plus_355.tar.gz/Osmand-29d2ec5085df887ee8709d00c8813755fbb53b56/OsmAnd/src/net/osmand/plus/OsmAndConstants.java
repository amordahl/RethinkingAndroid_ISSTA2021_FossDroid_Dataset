package net.osmand.plus;

public interface OsmAndConstants {
	
	
	public int UI_HANDLER_MAP_VIEW = 3000;
	
	public int UI_HANDLER_MAP_CONTROLS = 4000;
	
	public int UI_HANDLER_LOCATION_SERVICE = 5000;

	public int UI_HANDLER_PROGRESS = 6000;

	public int UI_HANDLER_SEARCH = 7000;

}
