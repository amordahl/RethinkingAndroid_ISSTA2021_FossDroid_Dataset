package net.osmand.plus;

import androidx.fragment.app.DialogFragment;

public interface OnDismissDialogFragmentListener {
	void onDismissDialogFragment(DialogFragment dialogFragment);
}
