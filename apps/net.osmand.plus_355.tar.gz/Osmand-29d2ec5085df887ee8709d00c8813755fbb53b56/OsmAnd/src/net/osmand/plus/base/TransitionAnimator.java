package net.osmand.plus.base;

public interface TransitionAnimator {

	void disableTransitionAnimation();

	void enableTransitionAnimation();
}
