package net.osmand;

public class ValueHolder<T> {

	public T value;
}
