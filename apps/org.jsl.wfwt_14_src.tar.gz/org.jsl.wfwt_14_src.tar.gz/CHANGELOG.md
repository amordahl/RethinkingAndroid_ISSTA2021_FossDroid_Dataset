# Change Log
All notable changes to this project will be documented in this file.

## 1.10
- fixed NPE on app restart
- fixed double activity instance on notification

## 1.9
- support background operation in receiver mode
