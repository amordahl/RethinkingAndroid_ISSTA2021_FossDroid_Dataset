==========
Free Fall
==========

:Project page: https://gitorious.org/free-fall/free-fall
:License: GNU General Public License v3+
:Version: 1.6.1
:Game Description: Save the Ball from getting crushed at the top of the screen by dodging the moving barriers using the accelerometer. To help you along the way some special bonus balls will appear, but be careful to not press the wrong one!

Notes:
This game is also available at the android market under the name "Crazy Ball": https://market.android.com/details?id=pt.isec.tp.am
The artwork from this version is somewhat different in order to maintain a completely free (as-in-freedom) version.
