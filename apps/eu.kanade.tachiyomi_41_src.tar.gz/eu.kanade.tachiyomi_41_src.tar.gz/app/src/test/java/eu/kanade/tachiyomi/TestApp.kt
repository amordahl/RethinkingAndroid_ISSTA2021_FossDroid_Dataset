package eu.kanade.tachiyomi

open class TestApp : App() {

    override fun setupAcra() {
        // Do nothing
    }

    override fun setupJobManager() {
        // Do nothing
    }
}
