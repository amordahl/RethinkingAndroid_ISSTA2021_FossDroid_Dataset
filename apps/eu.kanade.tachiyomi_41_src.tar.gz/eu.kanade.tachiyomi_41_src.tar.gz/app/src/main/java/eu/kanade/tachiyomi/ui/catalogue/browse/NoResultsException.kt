package eu.kanade.tachiyomi.ui.catalogue.browse

class NoResultsException : Exception()