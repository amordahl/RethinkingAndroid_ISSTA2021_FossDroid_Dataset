package eu.kanade.tachiyomi.ui.library

object LibrarySort {

    const val ALPHA = 0
    const val LAST_READ = 1
    const val LAST_UPDATED = 2
    const val UNREAD = 3
    const val TOTAL = 4
    const val SOURCE = 5
}