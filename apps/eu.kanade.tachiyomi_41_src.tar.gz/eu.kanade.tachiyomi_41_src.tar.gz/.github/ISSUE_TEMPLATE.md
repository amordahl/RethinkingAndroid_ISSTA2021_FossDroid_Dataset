**DO NOT OPEN ISSUES/REQUESTS RELATING TO EXTENSIONS/CATALOGUES IN THIS REPOSITORY. Open them at the following repository  https://github.com/inorichi/tachiyomi-extensions/**

**For all other requests Please fill out the form below and remove the first 3 lines of this template**

**App version:**

**Android version:**

**Issue/Request:**

**Steps to reproduce (if applicable)**

 1.
 2.
 3.

**Other details:**
