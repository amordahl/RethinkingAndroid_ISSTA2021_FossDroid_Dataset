short_name = "godot"
name = "Godot Engine"
major = 2
minor = 1
patch = 4
status = "stable"
