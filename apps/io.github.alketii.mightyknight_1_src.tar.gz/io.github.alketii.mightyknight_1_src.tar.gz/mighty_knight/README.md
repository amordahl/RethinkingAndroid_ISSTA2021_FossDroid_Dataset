# mighty-knight
Free Runner

### Todo
- [ ] Code Cleanup - I designed the game logic while coding
- [x] Desktop - For the moment, its playable only on Android
- [ ] Audio
- [ ] Sounds
- [ ] Adding more items
- [ ] Adding more obstacles
- [ ] Android publish

![Mighty Knight Screenshot](https://lut.im/51CbP3OLvz/BLLm1ug5NH0grHCH.jpg)
