cordova.define("org.apache.cordova.speech.speechsynthesis.SpeechSynthesisEvent", function(require, exports, module) {
var SpeechSynthesisEvent = function() {
    this.charIndex;
    this.elapsedTime;
    this.name;
};

module.exports = SpeechSynthesisEvent;

});
