Original idea
=============
- [Gram Games Team](http://gram.gs/)

Programming
===========
- [Lonami Exo](https://lonamiwebs.github.io/)

Art
===
- Icon by [JustMeErazem](https://github.com/JustMeErazem)
- [Lonami Exo](https://lonamiwebs.github.io/)

Fonts
=====
- `geosans-light` by [Manfred Klein](http://www.dafont.com/geo-sans-light.font)
- `the-next-font` by [Pindarots](http://www.dafont.com/the_next_font.font)

Sounds
======
- `game_over` by [BerduSmith](http://freesound.org/people/BerduSmith/sounds/335395/)
- `piece_drop` by [cabled_mess](http://freesound.org/people/cabled_mess/sounds/350906/)
- `invalid_drop` by [fins](http://freesound.org/people/fins/sounds/146726/)
- `strip_clear` by [Kastenfrosch](http://freesound.org/people/Kastenfrosch/sounds/162461/)
- `effect_vanish` by [LloydEvans09](http://freesound.org/people/LloydEvans09/sounds/321806/)
- `effect_waterdrop` by [wubitog](http://freesound.org/people/wubitog/sounds/188381/)
- `effect_evaporate` by [DissingCreeps](http://freesound.org/people/DissingCreeps/sounds/359153/)
- `effect_spin` by [martian](http://freesound.org/people/martian/sounds/182243/)
- `effect_explode` by [carlSablowEdwards](http://freesound.org/people/carlSablowEdwards/sounds/76801/)
