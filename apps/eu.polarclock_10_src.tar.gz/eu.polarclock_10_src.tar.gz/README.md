# PolarClock
A highly customizable polar clock written in HTML5

[<img src="https://f-droid.org/badge/get-it-on.png"
      alt="Get it on F-Droid"
      height="80">](https://f-droid.org/app/eu.polarclock)
 
If you want to get only the HTML files, you can find them in the [assets](/app/src/main/assets) folder

## Screenshots
<img src="./fastlane/metadata/android/en-US/images/phoneScreenshots/screenshot.png" width="250"><br>
<img src="./fastlane/metadata/android/en-US/images/phoneScreenshots/screenshot-landscape.png" height="250">
